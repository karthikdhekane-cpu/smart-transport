// Mock Route Data
import { BusRoute, BusStop } from '../types/index';

// Coimbatore College Area - Realistic GPS coordinates
const CENTER_LAT = 11.0168;
const CENTER_LNG = 76.9558;

// Generate realistic route by incrementing coordinates
function generateRoutePoints(
  startLat: number,
  startLng: number,
  points: number,
  direction: 'north' | 'south' | 'east' | 'west' | 'northeast' | 'northwest' | 'southeast' | 'southwest',
  spacing: number = 0.0008
): { lat: number; lng: number }[] {
  const coords = [];
  let lat = startLat;
  let lng = startLng;
  
  for (let i = 0; i < points; i++) {
    coords.push({ lat, lng });
    
    switch (direction) {
      case 'north':
        lat += spacing;
        break;
      case 'south':
        lat -= spacing;
        break;
      case 'east':
        lng += spacing;
        break;
      case 'west':
        lng -= spacing;
        break;
      case 'northeast':
        lat += spacing * 0.7;
        lng += spacing * 0.7;
        break;
      case 'northwest':
        lat += spacing * 0.7;
        lng -= spacing * 0.7;
        break;
      case 'southeast':
        lat -= spacing * 0.7;
        lng += spacing * 0.7;
        break;
      case 'southwest':
        lat -= spacing * 0.7;
        lng -= spacing * 0.7;
        break;
    }
  }
  
  return coords;
}

// Route A: Gandhipuram Loop
const routeA: BusRoute = {
  id: 'route-a',
  name: 'Route A — Gandhipuram Loop',
  color: '#00C853',
  totalDistance: 8500,
  estimatedDuration: 2400,
  stops: [
    {
      id: 'stop-a1',
      name: 'Gandhipuram Bus Stand',
      lat: 11.0168,
      lng: 76.9558,
      scheduledTime: '7:00 AM',
      dwellTime: 45,
      order: 0,
    },
    {
      id: 'stop-a2',
      name: 'Town Hall',
      lat: 11.0198,
      lng: 76.9588,
      scheduledTime: '7:08 AM',
      dwellTime: 30,
      order: 1,
    },
    {
      id: 'stop-a3',
      name: 'Peelamedu Junction',
      lat: 11.0228,
      lng: 76.9618,
      scheduledTime: '7:18 AM',
      dwellTime: 30,
      order: 2,
    },
    {
      id: 'stop-a4',
      name: 'Avinashi Road',
      lat: 11.0258,
      lng: 76.9648,
      scheduledTime: '7:25 AM',
      dwellTime: 20,
      order: 3,
    },
    {
      id: 'stop-a5',
      name: 'College Main Gate',
      lat: 11.0288,
      lng: 76.9678,
      scheduledTime: '7:35 AM',
      dwellTime: 60,
      order: 4,
    },
    {
      id: 'stop-a6',
      name: 'SBI Circle',
      lat: 11.0268,
      lng: 76.9708,
      scheduledTime: '7:42 AM',
      dwellTime: 20,
      order: 5,
    },
    {
      id: 'stop-a7',
      name: 'R.S. Puram',
      lat: 11.0238,
      lng: 76.9678,
      scheduledTime: '7:50 AM',
      dwellTime: 30,
      order: 6,
    },
    {
      id: 'stop-a8',
      name: 'Race Course',
      lat: 11.0208,
      lng: 76.9648,
      scheduledTime: '7:58 AM',
      dwellTime: 20,
      order: 7,
    },
    {
      id: 'stop-a9',
      name: 'Gandhipuram Bus Stand',
      lat: 11.0168,
      lng: 76.9558,
      scheduledTime: '8:05 AM',
      dwellTime: 60,
      order: 8,
    },
  ],
};

// Route B: RS Puram Express
const routeB: BusRoute = {
  id: 'route-b',
  name: 'Route B — RS Puram Express',
  color: '#FFD700',
  totalDistance: 6200,
  estimatedDuration: 1800,
  stops: [
    {
      id: 'stop-b1',
      name: 'RS Puram',
      lat: 11.0068,
      lng: 76.9458,
      scheduledTime: '6:50 AM',
      dwellTime: 45,
      order: 0,
    },
    {
      id: 'stop-b2',
      name: 'Race Course',
      lat: 11.0098,
      lng: 76.9488,
      scheduledTime: '7:00 AM',
      dwellTime: 20,
      order: 1,
    },
    {
      id: 'stop-b3',
      name: 'Coimbatore Junction',
      lat: 11.0128,
      lng: 76.9518,
      scheduledTime: '7:10 AM',
      dwellTime: 30,
      order: 2,
    },
    {
      id: 'stop-b4',
      name: 'Gandhipuram',
      lat: 11.0168,
      lng: 76.9558,
      scheduledTime: '7:22 AM',
      dwellTime: 40,
      order: 3,
    },
    {
      id: 'stop-b5',
      name: 'College Main Gate',
      lat: 11.0288,
      lng: 76.9678,
      scheduledTime: '7:45 AM',
      dwellTime: 60,
      order: 4,
    },
    {
      id: 'stop-b6',
      name: 'R.S. Puram',
      lat: 11.0068,
      lng: 76.9458,
      scheduledTime: '8:10 AM',
      dwellTime: 60,
      order: 5,
    },
  ],
};

// Route C: Peelamedu Circuit
const routeC: BusRoute = {
  id: 'route-c',
  name: 'Route C — Peelamedu Circuit',
  color: '#2196F3',
  totalDistance: 7100,
  estimatedDuration: 2100,
  stops: [
    {
      id: 'stop-c1',
      name: 'Peelamedu Junction',
      lat: 11.0098,
      lng: 76.9458,
      scheduledTime: '7:15 AM',
      dwellTime: 45,
      order: 0,
    },
    {
      id: 'stop-c2',
      name: 'Coimbatore Medical College',
      lat: 11.0118,
      lng: 76.9428,
      scheduledTime: '7:25 AM',
      dwellTime: 30,
      order: 1,
    },
    {
      id: 'stop-c3',
      name: 'Tiruchi Road',
      lat: 11.0138,
      lng: 76.9408,
      scheduledTime: '7:35 AM',
      dwellTime: 20,
      order: 2,
    },
    {
      id: 'stop-c4',
      name: 'Hosur Road',
      lat: 11.0158,
      lng: 76.9388,
      scheduledTime: '7:45 AM',
      dwellTime: 20,
      order: 3,
    },
    {
      id: 'stop-c5',
      name: 'Singanallur',
      lat: 11.0188,
      lng: 76.9368,
      scheduledTime: '7:55 AM',
      dwellTime: 30,
      order: 4,
    },
    {
      id: 'stop-c6',
      name: 'Bus Stand',
      lat: 11.0208,
      lng: 76.9398,
      scheduledTime: '8:05 AM',
      dwellTime: 60,
      order: 5,
    },
    {
      id: 'stop-c7',
      name: 'Peelamedu Junction',
      lat: 11.0098,
      lng: 76.9458,
      scheduledTime: '8:20 AM',
      dwellTime: 60,
      order: 6,
    },
  ],
};

// Route D: Singanallur Terminal
const routeD: BusRoute = {
  id: 'route-d',
  name: 'Route D — Singanallur Terminal',
  color: '#FF5722',
  totalDistance: 5800,
  estimatedDuration: 1700,
  stops: [
    {
      id: 'stop-d1',
      name: 'Singanallur Bus Stand',
      lat: 11.0318,
      lng: 76.9758,
      scheduledTime: '7:05 AM',
      dwellTime: 45,
      order: 0,
    },
    {
      id: 'stop-d2',
      name: 'Singanallur Police Station',
      lat: 11.0308,
      lng: 76.9728,
      scheduledTime: '7:12 AM',
      dwellTime: 20,
      order: 1,
    },
    {
      id: 'stop-d3',
      name: 'Six Feet Road',
      lat: 11.0298,
      lng: 76.9708,
      scheduledTime: '7:18 AM',
      dwellTime: 20,
      order: 2,
    },
    {
      id: 'stop-d4',
      name: 'Chinnavedampatti',
      lat: 11.0288,
      lng: 76.9688,
      scheduledTime: '7:25 AM',
      dwellTime: 30,
      order: 3,
    },
    {
      id: 'stop-d5',
      name: 'College Main Gate',
      lat: 11.0288,
      lng: 76.9678,
      scheduledTime: '7:32 AM',
      dwellTime: 60,
      order: 4,
    },
    {
      id: 'stop-d6',
      name: 'Chinnavedampatti',
      lat: 11.0288,
      lng: 76.9688,
      scheduledTime: '7:45 AM',
      dwellTime: 30,
      order: 5,
    },
    {
      id: 'stop-d7',
      name: 'Singanallur Bus Stand',
      lat: 11.0318,
      lng: 76.9758,
      scheduledTime: '8:00 AM',
      dwellTime: 60,
      order: 6,
    },
  ],
};

// Export mock routes
export const mockRoutes = {
  'route-a': routeA,
  'route-b': routeB,
  'route-c': routeC,
  'route-d': routeD,
};

// Default route for testing
export const getDefaultRoute = (): BusRoute => routeA;
